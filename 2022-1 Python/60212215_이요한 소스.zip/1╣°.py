num=1
while True:
    if(num<=10):
        print("나무를", num ," 번 찍었다.")
        num=num+1
    else:
        print("나무가 넘어갔다. 와우..!!")
        break
    
