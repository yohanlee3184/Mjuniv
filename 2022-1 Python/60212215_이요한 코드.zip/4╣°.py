for i in range(1,20):
    for j in range(1, 20):
        print(i*j, end=' ')
    print()